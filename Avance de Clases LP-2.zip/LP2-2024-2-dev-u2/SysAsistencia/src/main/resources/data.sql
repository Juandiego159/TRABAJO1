INSERT INTO `upeu_periodo` (`id`, `estado`, `nombre`) VALUES
                                                          (1, 'Activo', '2024-2'),
                                                          (2, 'Desactivo', '2024-1');