package pe.edu.upeu.sysasistencia.modelo;

import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.EqualsAndHashCode;

@Embeddable
@EqualsAndHashCode
public class UsuarioRolPK {
    @ManyToOne
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;@ManyToOne
    @JoinColumn(name = "rol_id")
    private Rol rol;
}