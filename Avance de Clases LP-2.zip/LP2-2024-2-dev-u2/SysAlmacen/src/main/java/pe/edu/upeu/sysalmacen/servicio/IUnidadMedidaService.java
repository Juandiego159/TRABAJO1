package pe.edu.upeu.sysalmacen.servicio;

import pe.edu.upeu.sysalmacen.modelo.Marca;
import pe.edu.upeu.sysalmacen.modelo.UnidadMedida;

public interface IUnidadMedidaService extends ICrudGenericoService<UnidadMedida, Long>{
}
