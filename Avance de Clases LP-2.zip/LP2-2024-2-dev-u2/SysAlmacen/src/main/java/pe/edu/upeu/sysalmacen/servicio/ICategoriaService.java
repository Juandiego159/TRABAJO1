package pe.edu.upeu.sysalmacen.servicio;

import pe.edu.upeu.sysalmacen.modelo.Categoria;
import pe.edu.upeu.sysalmacen.modelo.Marca;

public interface ICategoriaService extends ICrudGenericoService<Categoria, Long>{
}
