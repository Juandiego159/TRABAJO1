package com.example.SysAsistencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysAsistenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
